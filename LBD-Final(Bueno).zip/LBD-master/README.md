# LBD
Do you wanna see something of SQL
